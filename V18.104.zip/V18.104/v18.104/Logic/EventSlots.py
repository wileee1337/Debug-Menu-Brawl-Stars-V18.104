import time

class EventSlots:
    Timer = 86400

    maps = [
        # Status = [3 = Nothing, 2 = Star Token, 1 = New Event]
        {
            'ID': 7,
            'Status': 2,
            'Ended': False,
            'Modifier': 0,
            'Tokens': 10
        },

        {
            'ID': 32,
            'Status': 2,
            'Ended': False,
            'Modifier': 0,
            'Tokens': 10
        },

        {
            'ID': 24, # 24 - Football, 17 - Heist
            'Status': 2,
            'Ended': False,
            'Modifier': 0,
            'Tokens': 10
        },

        {
            'ID': 0,
            'Status': 2,
            'Ended': False,
            'Modifier': 0,
            'Tokens': 10
        },

    ]